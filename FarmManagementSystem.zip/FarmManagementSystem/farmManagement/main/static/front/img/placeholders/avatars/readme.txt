All avatars used in the demo are not available for commercial use,
so we couldn't include them in the final package. If you would like
them for mockup purposes, you can either replace the images in this
folder with avatars from http://uifaces.com/ or you can contact us
to send you the ones we've used in the demo (also from uifaces.com).

Thank you! :-)