from django.shortcuts import render,redirect,get_object_or_404
from .models import Main

# Create your views here.

def home(request):

    return render(request,'front/home.html')

